package com.example.panelpass;

import org.json.JSONObject;

public interface MessageHandler {
	void handleMessage(JSONObject message); 

}
